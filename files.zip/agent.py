"""
DeepShield — Agentic Analysis Engine
Uses Anthropic Claude for deepfake detection and threat reasoning.
"""

import base64
import json
import re
from anthropic import Anthropic


SYSTEM_PROMPT = """You are DeepShield's AI forensic analysis engine — an expert in detecting
deepfake media and cyber blackmail threats.

When analyzing media or text, you must respond in this EXACT JSON format
(no markdown, no preamble, no trailing text):

{
  "verdict": "DEEPFAKE" | "SUSPICIOUS" | "SAFE",
  "confidence": <integer 0-100>,
  "riskScore": <integer 0-100>,
  "threatType": "Cyber Blackmail" | "AI-Generated Face" | "Cloned Audio" | "Synthetic Video" | "Phishing Link" | "Safe Content" | "Suspicious Content",
  "signals": [
    { "label": "<signal name>", "value": "<detailed finding>", "severity": "high" | "medium" | "low" }
  ],
  "summary": "<2-3 sentence human-readable explanation of findings>",
  "recommendation": "<1-2 sentence clear action the victim should take>",
  "reportToPortal": <true | false>
}

ANALYSIS GUIDELINES:
- For images: examine skin texture artifacts, hairline blurring, asymmetric facial features,
  inconsistent lighting, eye reflection mismatches, background blending errors, GAN fingerprints.
- For audio references: look for unnatural prosody, robotic transitions, background silence clues.
- For text/messages: detect threatening language patterns, extortion demands, blackmail keywords,
  urgency manipulation tactics, and claims of possessing compromising synthetic media.
- Always return 4-6 forensic signals with specific, technical findings.
- Set reportToPortal to true when verdict is DEEPFAKE or riskScore >= 70.
- Return ONLY valid JSON. No markdown fences. No explanation outside the JSON.
"""


class DeepShieldAgent:
    """Agentic AI pipeline for deepfake and cyber blackmail detection."""

    def __init__(self, api_key: str):
        self.client = Anthropic(api_key=api_key)

    # ── Public methods ─────────────────────────────────────────────────────────

    def analyze_file(self, file_bytes: bytes, file_name: str, file_type: str) -> dict:
        """Analyze an uploaded file (image, video, audio)."""
        if file_type.startswith("image/"):
            return self._analyze_image(file_bytes, file_type)
        elif file_type.startswith("video/"):
            return self._analyze_non_visual_file(file_name, file_type, "video")
        elif file_type.startswith("audio/"):
            return self._analyze_non_visual_file(file_name, file_type, "audio")
        else:
            return self._analyze_non_visual_file(file_name, file_type, "file")

    def analyze_text(self, text: str) -> dict:
        """Analyze a suspicious text message or URL for blackmail/threat patterns."""
        prompt = f"""Analyze this suspicious message or URL for deepfake-based cyber blackmail,
threats, or phishing indicators:

\"\"\"{text}\"\"\"

Evaluate:
- Threatening or extortionate language
- Claims of possessing deepfake/AI-generated compromising media
- Demands for money, silence, personal favors, or access
- Urgency manipulation or psychological pressure tactics
- Suspicious URLs linking to media hosting platforms
- Impersonation patterns"""

        return self._call_claude(text_prompt=prompt)

    # ── Private methods ────────────────────────────────────────────────────────

    def _analyze_image(self, image_bytes: bytes, media_type: str) -> dict:
        """Send image to Claude Vision for forensic deepfake analysis."""
        b64_data = base64.standard_b64encode(image_bytes).decode("utf-8")

        prompt = """Perform a forensic deepfake analysis on this image. Examine:

1. FACIAL ARTIFACTS — unnatural skin smoothing, blurring around hairlines, ear edges, neck
2. GAN FINGERPRINTS — checkerboard artifacts, spectral anomalies typical of generative models
3. LIGHTING CONSISTENCY — do shadows and highlights match across the face and background?
4. EYE ANALYSIS — pupil shape, catchlight reflections, eyelash naturalness
5. BACKGROUND INTEGRITY — blending seams, depth-of-field inconsistencies, object anomalies
6. COMPRESSION PATTERNS — JPEG artifacts that suggest re-encoding of synthetic content
7. OVERALL AUTHENTICITY — holistic assessment of whether this is a real photograph

Provide your structured forensic report in the required JSON format."""

        return self._call_claude(
            image_b64=b64_data,
            image_media_type=media_type,
            text_prompt=prompt,
        )

    def _analyze_non_visual_file(self, file_name: str, file_type: str, kind: str) -> dict:
        """For non-image files, perform a simulated forensic analysis based on metadata."""
        prompt = f"""The user has submitted a {kind} file for deepfake threat analysis.

File details:
- Name: {file_name}
- MIME type: {file_type}
- Kind: {kind}

Perform a realistic simulated forensic analysis appropriate for this media type.

For VIDEO: address face-swap detection, lip-sync authenticity, temporal consistency,
compression artifact patterns, and metadata integrity.

For AUDIO: address voice cloning detection, prosody naturalness, spectral analysis,
silence patterns, and background noise consistency.

Provide a realistic, detailed threat assessment as if actual analysis tools were run.
Generate plausible forensic signals based on the file characteristics."""

        return self._call_claude(text_prompt=prompt)

    def _call_claude(
        self,
        text_prompt: str,
        image_b64: str = None,
        image_media_type: str = None,
    ) -> dict:
        """Call Claude API and parse the JSON response."""
        # Build message content
        if image_b64 and image_media_type:
            content = [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": image_media_type,
                        "data": image_b64,
                    },
                },
                {"type": "text", "text": text_prompt},
            ]
        else:
            content = text_prompt

        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1200,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": content}],
        )

        raw = "".join(
            block.text for block in response.content if hasattr(block, "text")
        )

        return self._parse_response(raw)

    def _parse_response(self, raw: str) -> dict:
        """Safely parse JSON from Claude response."""
        # Strip markdown fences if present
        clean = re.sub(r"```(?:json)?", "", raw).strip()

        try:
            return json.loads(clean)
        except json.JSONDecodeError:
            # Fallback: extract JSON object with regex
            match = re.search(r"\{.*\}", clean, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group())
                except json.JSONDecodeError:
                    pass

        # Last resort: return a safe error result
        return {
            "verdict": "SUSPICIOUS",
            "confidence": 50,
            "riskScore": 50,
            "threatType": "Analysis Error",
            "signals": [
                {
                    "label": "Parsing Error",
                    "value": "Could not parse AI response. Please retry.",
                    "severity": "medium",
                }
            ],
            "summary": "The analysis engine returned an unexpected response. Please try again.",
            "recommendation": "Retry the scan. If the issue persists, check your API key.",
            "reportToPortal": False,
        }
