# 🛡️ DeepShield — Agentic Deepfake Threat Detection

A Python web app that detects AI-generated deepfake media and cyber blackmail threats
using Claude's vision and reasoning capabilities.

---

## 📁 Project Structure

```
deepshield_app/
├── app.py              ← Streamlit frontend (UI)
├── agent.py            ← AI analysis engine (Claude API)
├── report.py           ← PDF evidence report generator
├── requirements.txt    ← Python dependencies
└── README.md
```

---

## ⚡ Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Get your free Anthropic API key
Sign up at: https://console.anthropic.com  
(Free tier available — no credit card needed for testing)

### 3. Run the app
```bash
streamlit run app.py
```

### 4. Open in browser
Navigate to: http://localhost:8501

Enter your Anthropic API key in the UI when prompted.

---

## 🔑 Environment Variable (Optional)

Set your API key as an environment variable to skip the UI prompt:

```bash
export ANTHROPIC_API_KEY=sk-ant-your-key-here
streamlit run app.py
```

---

## 🌐 Deploy Free on Streamlit Community Cloud

1. Push this folder to a GitHub repo
2. Go to share.streamlit.io
3. Connect your repo → select `app.py`
4. Add `ANTHROPIC_API_KEY` in Secrets settings
5. Deploy — live URL in 2 minutes ✅

---

## 🧠 How It Works

```
User uploads image / video / audio / pastes text
         ↓
agent.py — sends to Claude API with forensic system prompt
         ↓
Claude analyzes: GAN artifacts, facial inconsistencies,
                 threat language, blackmail patterns
         ↓
Returns structured JSON: verdict, risk score, signals
         ↓
app.py renders results dashboard
         ↓
report.py generates downloadable PDF evidence report
```

---

## 📊 Output Fields

| Field | Description |
|---|---|
| `verdict` | DEEPFAKE / SUSPICIOUS / SAFE |
| `riskScore` | 0–100 composite threat score |
| `confidence` | AI model confidence % |
| `threatType` | Category of threat detected |
| `signals` | List of forensic findings with severity |
| `summary` | Human-readable explanation |
| `recommendation` | Suggested action for victim |
| `reportToPortal` | Whether to escalate to cybercrime portal |

---

## 🛠️ Tech Stack (All Free)

| Layer | Tool |
|---|---|
| Frontend | Streamlit |
| AI Engine | Anthropic Claude (claude-sonnet-4) |
| Vision Analysis | Claude Vision API |
| PDF Reports | ReportLab |
| Hosting | Streamlit Community Cloud |

---

## ⚠️ Disclaimer

DeepShield is a prototype built for hackathon demonstration.
AI findings should be reviewed by a qualified cybersecurity professional
before being used as legal evidence.
