"""
DeepShield - Agentic Deepfake Threat Detection
Streamlit Frontend
Run: streamlit run app.py
"""

import streamlit as st
import base64
import json
import time
import os
from pathlib import Path
from agent import DeepShieldAgent
from report import generate_pdf_report

# ── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="DeepShield | Deepfake Threat Detection",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Exo+2:wght@400;700;900&display=swap');

html, body, [class*="css"] {
    background-color: #040810;
    color: #E2E8F0;
    font-family: 'Share Tech Mono', monospace;
}

.main { background-color: #040810; }
.block-container { padding-top: 2rem; max-width: 1000px; }

/* Header */
.deepshield-header {
    display: flex; align-items: center; gap: 14px;
    padding: 16px 0 32px;
    border-bottom: 1px solid rgba(0,255,136,0.15);
    margin-bottom: 32px;
}
.logo-box {
    width: 48px; height: 48px;
    background: linear-gradient(135deg, #00FF88, #00D4FF);
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 24px;
    box-shadow: 0 0 24px rgba(0,255,136,0.4);
}
.brand-name {
    font-size: 28px; font-weight: 900;
    letter-spacing: 6px; color: #00FF88;
    font-family: 'Exo 2', sans-serif;
}
.brand-sub {
    font-size: 10px; color: #334155;
    letter-spacing: 3px; margin-top: -4px;
}
.status-pill {
    margin-left: auto;
    background: rgba(0,255,136,0.08);
    border: 1px solid rgba(0,255,136,0.2);
    border-radius: 20px; padding: 6px 16px;
    font-size: 11px; color: #00FF88;
    letter-spacing: 2px;
}

/* Cards */
.card {
    background: rgba(255,255,255,0.02);
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 14px; padding: 24px;
    margin-bottom: 16px;
}
.card-label {
    font-size: 10px; letter-spacing: 3px;
    color: #475569; margin-bottom: 14px;
    text-transform: uppercase;
}

/* Verdict badges */
.verdict-deepfake {
    display: inline-block; padding: 10px 28px;
    background: rgba(255,59,92,0.12);
    border: 1px solid rgba(255,59,92,0.4);
    border-radius: 40px; color: #FF3B5C;
    font-size: 18px; font-weight: 900;
    letter-spacing: 4px;
    box-shadow: 0 0 24px rgba(255,59,92,0.2);
}
.verdict-suspicious {
    display: inline-block; padding: 10px 28px;
    background: rgba(255,149,0,0.12);
    border: 1px solid rgba(255,149,0,0.4);
    border-radius: 40px; color: #FF9500;
    font-size: 18px; font-weight: 900;
    letter-spacing: 4px;
    box-shadow: 0 0 24px rgba(255,149,0,0.2);
}
.verdict-safe {
    display: inline-block; padding: 10px 28px;
    background: rgba(0,255,136,0.12);
    border: 1px solid rgba(0,255,136,0.4);
    border-radius: 40px; color: #00FF88;
    font-size: 18px; font-weight: 900;
    letter-spacing: 4px;
    box-shadow: 0 0 24px rgba(0,255,136,0.2);
}

/* Signal rows */
.signal-row {
    display: flex; align-items: center; gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid rgba(255,255,255,0.04);
    font-size: 13px;
}
.signal-dot-high  { color: #FF3B5C; font-size: 10px; }
.signal-dot-med   { color: #FF9500; font-size: 10px; }
.signal-dot-low   { color: #00FF88; font-size: 10px; }
.severity-high  { background: rgba(255,59,92,0.1);  color: #FF3B5C; padding: 2px 8px; border-radius: 10px; font-size: 10px; }
.severity-medium{ background: rgba(255,149,0,0.1); color: #FF9500; padding: 2px 8px; border-radius: 10px; font-size: 10px; }
.severity-low   { background: rgba(0,255,136,0.1); color: #00FF88; padding: 2px 8px; border-radius: 10px; font-size: 10px; }

/* Upload zone */
.upload-hint {
    text-align: center; padding: 8px 0;
    color: #334155; font-size: 11px; letter-spacing: 2px;
}

/* Recommendation box */
.rec-box {
    background: rgba(99,102,241,0.07);
    border: 1px solid rgba(99,102,241,0.2);
    border-radius: 10px; padding: 16px 20px;
    font-size: 13px; color: #94A3B8;
    line-height: 1.7;
}

/* Alert box */
.alert-box {
    background: rgba(255,59,92,0.08);
    border: 1px solid rgba(255,59,92,0.25);
    border-radius: 10px; padding: 12px 18px;
    color: #FF3B5C; font-size: 12px;
    letter-spacing: 1px; text-align: center;
    margin-top: 12px;
}

/* Stats */
.stat-box {
    background: rgba(255,255,255,0.02);
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 10px; padding: 16px;
    text-align: center;
}
.stat-value {
    font-size: 28px; font-weight: 900;
    color: #00FF88; letter-spacing: 2px;
}
.stat-label {
    font-size: 10px; color: #334155;
    letter-spacing: 1px; margin-top: 4px;
}

/* Hide Streamlit default elements */
#MainMenu { visibility: hidden; }
footer { visibility: hidden; }
header { visibility: hidden; }
.stDeployButton { display: none; }

/* Button overrides */
.stButton > button {
    background: linear-gradient(135deg, #00FF88, #00D4FF) !important;
    color: #040810 !important;
    border: none !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-weight: 900 !important;
    letter-spacing: 3px !important;
    font-size: 14px !important;
    padding: 14px 40px !important;
    border-radius: 10px !important;
    box-shadow: 0 0 28px rgba(0,255,136,0.25) !important;
    width: 100% !important;
    transition: all 0.2s !important;
}
.stButton > button:hover {
    box-shadow: 0 0 44px rgba(0,255,136,0.45) !important;
    transform: translateY(-1px) !important;
}

/* Secondary button */
.stButton.secondary > button {
    background: transparent !important;
    color: #64748B !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
    box-shadow: none !important;
}

/* Progress bar */
.stProgress > div > div {
    background: linear-gradient(90deg, #00FF88, #00D4FF) !important;
}

/* Text input */
.stTextArea textarea {
    background: rgba(255,255,255,0.02) !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
    color: #E2E8F0 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 13px !important;
    border-radius: 10px !important;
}
.stTextArea textarea:focus {
    border-color: rgba(0,255,136,0.4) !important;
    box-shadow: 0 0 0 1px rgba(0,255,136,0.2) !important;
}

/* File uploader */
.stFileUploader {
    background: rgba(255,255,255,0.01) !important;
    border: 2px dashed rgba(255,255,255,0.1) !important;
    border-radius: 12px !important;
}
[data-testid="stFileUploaderDropzone"] {
    background: rgba(255,255,255,0.01) !important;
    border: 2px dashed rgba(255,255,255,0.12) !important;
    border-radius: 12px !important;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {
    background: transparent !important;
    gap: 8px;
}
.stTabs [data-baseweb="tab"] {
    background: rgba(255,255,255,0.02) !important;
    border: 1px solid rgba(255,255,255,0.08) !important;
    border-radius: 6px !important;
    color: #475569 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 11px !important;
    letter-spacing: 2px !important;
}
.stTabs [aria-selected="true"] {
    background: rgba(0,255,136,0.1) !important;
    border-color: #00FF88 !important;
    color: #00FF88 !important;
}
.stTabs [data-baseweb="tab-highlight"] { display: none !important; }
.stTabs [data-baseweb="tab-border"] { display: none !important; }

/* Metric */
[data-testid="stMetricValue"] {
    color: #00FF88 !important;
    font-family: 'Share Tech Mono', monospace !important;
}
</style>
""", unsafe_allow_html=True)


# ── Session State ──────────────────────────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []
if "result" not in st.session_state:
    st.session_state.result = None
if "api_key" not in st.session_state:
    st.session_state.api_key = os.getenv("ANTHROPIC_API_KEY", "")


# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="deepshield-header">
    <div class="logo-box">🛡️</div>
    <div>
        <div class="brand-name">DEEPSHIELD</div>
        <div class="brand-sub">AGENTIC DEEPFAKE THREAT DETECTION SYSTEM</div>
    </div>
    <div class="status-pill">● SYSTEM ONLINE</div>
</div>
""", unsafe_allow_html=True)


# ── API Key Setup ──────────────────────────────────────────────────────────────
if not st.session_state.api_key:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.markdown('<div class="card-label">🔑 API CONFIGURATION</div>', unsafe_allow_html=True)
    key_input = st.text_input(
        "Anthropic API Key",
        type="password",
        placeholder="sk-ant-...",
        help="Get your free key at console.anthropic.com",
        label_visibility="collapsed",
    )
    st.caption("🔒 Your key is stored in session memory only — never saved to disk.")
    if key_input:
        st.session_state.api_key = key_input
        st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)
    st.stop()


# ── Main Tabs ──────────────────────────────────────────────────────────────────
tab_scan, tab_history, tab_about = st.tabs(["⚡ SCAN", f"📋 HISTORY ({len(st.session_state.history)})", "ℹ️ ABOUT"])


# ══════════════════════════════════════════════════════════════════════════════
# SCAN TAB
# ══════════════════════════════════════════════════════════════════════════════
with tab_scan:

    # Hero text (only when no result)
    if not st.session_state.result:
        st.markdown("""
        <div style="text-align:center; padding: 20px 0 36px;">
            <div style="font-size:11px; letter-spacing:5px; color:#00FF88; margin-bottom:14px; opacity:0.7;">
                AI-POWERED FORENSIC ANALYSIS
            </div>
            <h1 style="font-size:clamp(28px,4vw,46px); font-weight:900; line-height:1.15;
                background:linear-gradient(135deg,#E2E8F0 30%,#00FF88);
                -webkit-background-clip:text; -webkit-text-fill-color:transparent;
                letter-spacing:-1px; margin:0 0 14px; font-family:'Exo 2',sans-serif;">
                Detect Deepfakes.<br/>Stop Cyber Blackmail.
            </h1>
            <p style="color:#475569; font-size:14px; max-width:460px; margin:0 auto; line-height:1.8;">
                Upload any image, video, or audio — our agentic AI pipeline analyzes it
                for synthetic manipulation and cyber threat patterns in seconds.
            </p>
        </div>
        """, unsafe_allow_html=True)

    # ── Input Mode ──────────────────────────────────────────────────────────
    col_mode1, col_mode2 = st.columns(2)
    with col_mode1:
        input_mode = st.radio(
            "Input Mode",
            ["📁 Upload File", "📝 Paste Text / URL"],
            horizontal=True,
            label_visibility="collapsed",
        )
    st.markdown("---", )

    uploaded_file = None
    text_input = ""

    if "Upload" in input_mode:
        uploaded_file = st.file_uploader(
            "Drop your file here",
            type=["jpg", "jpeg", "png", "webp", "mp4", "mov", "mp3", "wav", "ogg"],
            help="Supported: Images (JPG/PNG/WEBP), Video (MP4/MOV), Audio (MP3/WAV)",
            label_visibility="collapsed",
        )
        st.markdown('<div class="upload-hint">JPG · PNG · WEBP · MP4 · MOV · MP3 · WAV</div>', unsafe_allow_html=True)

        if uploaded_file and uploaded_file.type.startswith("image/"):
            st.image(uploaded_file, use_container_width=False, width=380)

    else:
        text_input = st.text_area(
            "Suspicious content",
            placeholder="Paste a threatening message, blackmail text, or suspicious URL...\n\nExample: 'I have deepfake videos of you. Pay $500 or I'll send them to your contacts.'",
            height=160,
            label_visibility="collapsed",
        )

    st.markdown("<br/>", unsafe_allow_html=True)

    # ── Scan Button ──────────────────────────────────────────────────────────
    can_scan = (uploaded_file is not None) or (text_input.strip() != "")

    if can_scan:
        if st.button("⚡ RUN THREAT ANALYSIS", use_container_width=True):

            # ── Scanning UI ─────────────────────────────────────────────────
            scan_container = st.container()
            with scan_container:
                st.markdown("""
                <div style="text-align:center; padding:12px 0 8px;">
                    <span style="font-size:11px; letter-spacing:3px; color:#00FF88;">ANALYZING...</span>
                </div>
                """, unsafe_allow_html=True)

                progress_bar = st.progress(0)
                status_text = st.empty()

                stages = [
                    (0.15, "🔬 Extracting media fingerprint..."),
                    (0.35, "🧬 Running deepfake detection model..."),
                    (0.55, "👁️  Analyzing facial artifacts & GAN traces..."),
                    (0.75, "🤖 Invoking threat reasoning agent..."),
                    (0.90, "📊 Generating forensic report..."),
                    (1.00, "✅ Analysis complete."),
                ]

                for prog, msg in stages:
                    progress_bar.progress(prog)
                    status_text.markdown(
                        f'<div style="text-align:center; color:#64748B; font-size:12px; letter-spacing:1px;">{msg}</div>',
                        unsafe_allow_html=True,
                    )
                    time.sleep(0.6)

            # ── Run Agent ───────────────────────────────────────────────────
            agent = DeepShieldAgent(api_key=st.session_state.api_key)

            with st.spinner(""):
                if uploaded_file:
                    file_bytes = uploaded_file.read()
                    result = agent.analyze_file(
                        file_bytes=file_bytes,
                        file_name=uploaded_file.name,
                        file_type=uploaded_file.type,
                    )
                else:
                    result = agent.analyze_text(text_input.strip())

            # Save to state
            st.session_state.result = result
            st.session_state.history.append({
                "id": int(time.time()),
                "name": uploaded_file.name if uploaded_file else text_input[:50] + "...",
                "time": time.strftime("%H:%M:%S"),
                "result": result,
            })
            st.rerun()

    # ── Results ───────────────────────────────────────────────────────────────
    if st.session_state.result:
        r = st.session_state.result

        # Clear button
        col_clear, _ = st.columns([1, 4])
        with col_clear:
            if st.button("← NEW SCAN"):
                st.session_state.result = None
                st.rerun()

        st.markdown("<br/>", unsafe_allow_html=True)

        # ── Row 1: Verdict + Risk Score ──────────────────────────────────────
        col_v, col_r = st.columns(2)

        with col_v:
            verdict = r.get("verdict", "SUSPICIOUS")
            verdict_class = f"verdict-{verdict.lower()}"
            threat_type = r.get("threatType", "Unknown")
            summary = r.get("summary", "")

            st.markdown(f"""
            <div class="card" style="height:100%;">
                <div class="card-label">VERDICT</div>
                <div style="text-align:center; padding: 12px 0;">
                    <div class="{verdict_class}">{verdict}</div>
                    <div style="margin-top:14px; font-size:12px; color:#64748B;
                        background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.06);
                        border-radius:8px; padding:8px 16px; display:inline-block;">
                        {threat_type}
                    </div>
                    <div style="margin-top:16px; font-size:12px; color:#94A3B8; line-height:1.8;">
                        {summary}
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        with col_r:
            risk = r.get("riskScore", 0)
            conf = r.get("confidence", 0)
            risk_color = "#FF3B5C" if risk >= 70 else "#FF9500" if risk >= 40 else "#00FF88"
            report_flag = r.get("reportToPortal", False)

            st.markdown(f"""
            <div class="card" style="height:100%;">
                <div class="card-label">RISK SCORE</div>
                <div style="text-align:center;">
                    <div style="font-size:72px; font-weight:900; color:{risk_color};
                        line-height:1; letter-spacing:-2px; font-family:'Exo 2',sans-serif;
                        text-shadow: 0 0 32px {risk_color}60;">
                        {risk}
                    </div>
                    <div style="font-size:10px; color:#475569; letter-spacing:2px; margin-top:4px;">/ 100</div>
                    <div style="margin-top:20px; margin-bottom:6px; display:flex; justify-content:space-between; font-size:11px;">
                        <span style="color:#475569;">AI CONFIDENCE</span>
                        <span style="color:#00FF88;">{conf}%</span>
                    </div>
                    <div style="height:6px; background:rgba(255,255,255,0.05); border-radius:3px;">
                        <div style="height:100%; width:{conf}%; background:linear-gradient(90deg,#00FF88,#00D4FF); border-radius:3px;"></div>
                    </div>
                    {"<div class='alert-box'>⚠ REPORT TO CYBERCRIME PORTAL RECOMMENDED</div>" if report_flag else ""}
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("<br/>", unsafe_allow_html=True)

        # ── Forensic Signals ─────────────────────────────────────────────────
        signals = r.get("signals", [])
        if signals:
            st.markdown('<div class="card">', unsafe_allow_html=True)
            st.markdown('<div class="card-label">🔬 FORENSIC SIGNALS</div>', unsafe_allow_html=True)

            for sig in signals:
                sev = sig.get("severity", "low")
                dot_class = f"signal-dot-{sev if sev in ['high','med'] else 'low'}"
                badge_class = f"severity-{sev if sev in ['high','medium','low'] else 'low'}"
                st.markdown(f"""
                <div class="signal-row">
                    <span class="{dot_class}">◆</span>
                    <div style="flex:1;">
                        <div style="font-size:11px; color:#64748B; letter-spacing:1px;">{sig.get('label','')}</div>
                        <div style="font-size:13px; color:#E2E8F0; margin-top:2px;">{sig.get('value','')}</div>
                    </div>
                    <span class="{badge_class}">{sev.upper()}</span>
                </div>
                """, unsafe_allow_html=True)

            st.markdown('</div>', unsafe_allow_html=True)

        # ── Recommendation ────────────────────────────────────────────────────
        rec = r.get("recommendation", "")
        if rec:
            st.markdown(f"""
            <div style="margin-bottom:16px;">
                <div class="card-label" style="margin-bottom:8px;">💡 RECOMMENDED ACTION</div>
                <div class="rec-box">
                    {rec}
                </div>
            </div>
            """, unsafe_allow_html=True)

        # ── PDF Download ──────────────────────────────────────────────────────
        st.markdown('<div class="card-label">📄 EVIDENCE EXPORT</div>', unsafe_allow_html=True)
        pdf_bytes = generate_pdf_report(r)
        st.download_button(
            label="⬇ DOWNLOAD PDF EVIDENCE REPORT",
            data=pdf_bytes,
            file_name=f"deepshield_report_{int(time.time())}.pdf",
            mime="application/pdf",
            use_container_width=True,
        )

    # ── Stats (when no result) ────────────────────────────────────────────────
    if not st.session_state.result and not can_scan:
        st.markdown("<br/><br/>", unsafe_allow_html=True)
        h = st.session_state.history
        col_s1, col_s2, col_s3 = st.columns(3)
        with col_s1:
            st.markdown(f'<div class="stat-box"><div class="stat-value">{len(h):03d}</div><div class="stat-label">SCANS TODAY</div></div>', unsafe_allow_html=True)
        with col_s2:
            df_count = sum(1 for x in h if x["result"].get("verdict") == "DEEPFAKE")
            st.markdown(f'<div class="stat-box"><div class="stat-value">{df_count:03d}</div><div class="stat-label">DEEPFAKES FOUND</div></div>', unsafe_allow_html=True)
        with col_s3:
            avg = int(sum(x["result"].get("riskScore", 0) for x in h) / len(h)) if h else 0
            st.markdown(f'<div class="stat-box"><div class="stat-value">{avg if h else "---"}</div><div class="stat-label">AVG RISK SCORE</div></div>', unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# HISTORY TAB
# ══════════════════════════════════════════════════════════════════════════════
with tab_history:
    history = st.session_state.history

    if not history:
        st.markdown("""
        <div style="text-align:center; padding:60px 0; color:#334155; font-size:13px;">
            No scans yet. Go to the Scan tab to analyze media.
        </div>
        """, unsafe_allow_html=True)
    else:
        for item in reversed(history):
            r = item["result"]
            verdict = r.get("verdict", "SUSPICIOUS")
            color = "#FF3B5C" if verdict == "DEEPFAKE" else "#FF9500" if verdict == "SUSPICIOUS" else "#00FF88"
            risk = r.get("riskScore", 0)

            with st.expander(f"[{item['time']}]  {item['name'][:60]}  —  Risk: {risk}"):
                col1, col2, col3 = st.columns(3)
                col1.metric("Verdict", verdict)
                col2.metric("Risk Score", f"{risk}/100")
                col3.metric("Confidence", f"{r.get('confidence', 0)}%")
                st.markdown(f"**Threat Type:** {r.get('threatType', 'N/A')}")
                st.markdown(f"**Summary:** {r.get('summary', '')}")
                st.markdown(f"**Recommendation:** {r.get('recommendation', '')}")


# ══════════════════════════════════════════════════════════════════════════════
# ABOUT TAB
# ══════════════════════════════════════════════════════════════════════════════
with tab_about:
    st.markdown("""
    <div class="card">
        <div class="card-label">ABOUT DEEPSHIELD</div>
        <p style="color:#94A3B8; line-height:1.9; font-size:13px;">
            DeepShield is an agentic AI platform that detects deepfake media and
            identifies cyber blackmail threats. It combines computer vision forensics
            with large language model reasoning to produce actionable threat reports.
        </p>
    </div>

    <div class="card">
        <div class="card-label">DETECTION PIPELINE</div>
        <div style="font-size:12px; color:#64748B; line-height:2.4;">
            <span style="color:#00FF88;">01</span> &nbsp; Media ingestion + file fingerprinting<br/>
            <span style="color:#FF6B35;">02</span> &nbsp; Deepfake model inference (Claude Vision)<br/>
            <span style="color:#A855F7;">03</span> &nbsp; Agentic threat reasoning (LLM)<br/>
            <span style="color:#F59E0B;">04</span> &nbsp; Risk score aggregation<br/>
            <span style="color:#10B981;">05</span> &nbsp; PDF evidence report generation
        </div>
    </div>

    <div class="card">
        <div class="card-label">TECH STACK</div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; font-size:12px; color:#64748B;">
            <div>⚡ <span style="color:#E2E8F0;">Frontend</span> — Streamlit</div>
            <div>🤖 <span style="color:#E2E8F0;">AI Engine</span> — Claude (Anthropic)</div>
            <div>🧬 <span style="color:#E2E8F0;">Vision</span> — Claude Vision API</div>
            <div>📄 <span style="color:#E2E8F0;">Reports</span> — ReportLab PDF</div>
            <div>🐍 <span style="color:#E2E8F0;">Backend</span> — Python 3.10+</div>
            <div>🚀 <span style="color:#E2E8F0;">Hosting</span> — Streamlit Community Cloud</div>
        </div>
    </div>

    <div class="card">
        <div class="card-label">FREE APIS USED</div>
        <div style="font-size:12px; color:#64748B; line-height:2.4;">
            <span style="color:#00FF88;">●</span> &nbsp; Anthropic Claude API — console.anthropic.com<br/>
            <span style="color:#00D4FF;">●</span> &nbsp; Streamlit Community Cloud — share.streamlit.io (free hosting)
        </div>
    </div>
    """, unsafe_allow_html=True)
