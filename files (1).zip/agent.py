"""
DeepShield — Agentic Analysis Engine
Uses Groq API (FREE) — llama-3.3-70b-versatile
Get free key: https://console.groq.com  (no credit card needed)
"""

import json
import re
from groq import Groq

SYSTEM_PROMPT = """You are DeepShield's AI forensic analysis engine — an expert in detecting
deepfake media and cyber blackmail threats.

Respond ONLY in this exact JSON format (no markdown, no preamble, raw JSON only):

{
  "verdict": "DEEPFAKE" | "SUSPICIOUS" | "SAFE",
  "confidence": <integer 0-100>,
  "riskScore": <integer 0-100>,
  "threatType": "Cyber Blackmail" | "AI-Generated Face" | "Cloned Audio" | "Synthetic Video" | "Phishing Link" | "Safe Content" | "Suspicious Content",
  "signals": [
    { "label": "<signal name>", "value": "<detailed finding>", "severity": "high" | "medium" | "low" }
  ],
  "summary": "<2-3 sentence human-readable explanation>",
  "recommendation": "<1-2 sentence action for the victim>",
  "reportToPortal": <true | false>
}

RULES:
- Return exactly 4-6 forensic signals.
- Set reportToPortal=true when verdict is DEEPFAKE or riskScore >= 70.
- Return ONLY valid JSON. No markdown. No text outside the JSON object.
"""


class DeepShieldAgent:
    """Agentic deepfake + cyber blackmail detection pipeline using Groq (free)."""

    def __init__(self, api_key: str):
        self.client = Groq(api_key=api_key)
        self.model  = "llama-3.3-70b-versatile"

    # ── Public ─────────────────────────────────────────────────────────────────

    def analyze_file(self, file_bytes: bytes, file_name: str, file_type: str) -> dict:
        if file_type.startswith("image/"):
            return self._analyze_image(file_bytes, file_type, file_name)
        elif file_type.startswith("video/"):
            return self._analyze_av(file_name, file_type, "video")
        elif file_type.startswith("audio/"):
            return self._analyze_av(file_name, file_type, "audio")
        return self._analyze_av(file_name, file_type, "file")

    def analyze_text(self, text: str) -> dict:
        prompt = f"""Analyze this content for deepfake-based cyber blackmail, threats, or phishing:

\"\"\"{text}\"\"\"

Evaluate for:
- Threatening / extortionate language
- Claims of possessing AI-generated compromising media
- Demands for money, silence, or personal favors
- Urgency manipulation tactics
- Suspicious media-hosting URLs
- Impersonation patterns

Return your forensic report in the required JSON format."""
        return self._call(prompt)

    # ── Private ────────────────────────────────────────────────────────────────

    def _analyze_image(self, image_bytes: bytes, media_type: str, file_name: str) -> dict:
        size_kb      = len(image_bytes) / 1024
        dimensions   = "unknown"
        color_mode   = "unknown"
        exif_details = "No EXIF data — strong AI-generation indicator"

        try:
            from PIL import Image
            import io as _io
            img        = Image.open(_io.BytesIO(image_bytes))
            dimensions = f"{img.width}x{img.height}px"
            color_mode = img.mode
            try:
                exif = img._getexif()
                exif_details = (
                    f"{len(exif)} EXIF tags found (camera metadata present)" if exif
                    else "No EXIF data — strong indicator of synthetic/AI generation"
                )
            except Exception:
                exif_details = "EXIF read failed — metadata may have been stripped"
        except Exception:
            pass

        prompt = f"""Forensic deepfake image analysis requested.

FILE METADATA:
- Filename    : {file_name}
- MIME type   : {media_type}
- File size   : {size_kb:.1f} KB
- Dimensions  : {dimensions}
- Color mode  : {color_mode}
- EXIF status : {exif_details}

Analyze across these forensic dimensions:
1. EXIF ANALYSIS       — Real cameras embed device/GPS/timestamp. Absence = AI generation.
2. FILE SIZE           — Is {size_kb:.1f} KB natural for {dimensions}? Suspiciously small/round = AI.
3. COLOR MODE          — Is {color_mode} consistent with authentic camera output?
4. FILENAME PATTERN    — Does "{file_name}" match AI generator output patterns (UUID, "generated_", etc)?
5. GAN FINGERPRINT     — Probability of GAN/diffusion origin based on all signals.
6. COMPRESSION PROFILE — AI images show distinct compression patterns vs real camera photos.

Return a complete forensic report in the required JSON format."""
        return self._call(prompt)

    def _analyze_av(self, file_name: str, file_type: str, kind: str) -> dict:
        video_guide = """
VIDEO FORENSICS — analyze:
- Face-swap likelihood: temporal flickering, unnatural skin/hair boundaries
- Lip-sync authenticity: audio-visual sync anomalies
- Frame consistency: abrupt texture changes, resolution mismatches
- Codec anomalies: unusual codecs preferred by deepfake pipelines
- Metadata integrity: missing timestamps, encoder strings from known deepfake tools""" if kind == "video" else ""

        audio_guide = """
AUDIO FORENSICS — analyze:
- Voice cloning likelihood: unnatural prosody, pitch robotic transitions
- Spectral anomalies: frequency gaps typical of neural TTS
- Silence patterns: unnaturally clean silence between words (TTS artifact)
- Background consistency: abrupt noise changes indicating splicing
- Codec fingerprinting: formats preferred by voice cloning tools
- Sample rate / bit depth: inconsistencies with claimed recording context""" if kind == "audio" else ""

        prompt = f"""Forensic {kind} deepfake analysis requested.

FILE DETAILS:
- Filename  : {file_name}
- MIME type : {file_type}
{video_guide}
{audio_guide}

Also analyze filename "{file_name}":
- Does it match patterns from known deepfake tools?
- (e.g., "swap", "deepfake", "generated", UUID strings, iterative suffixes)

Generate specific, technically detailed forensic signals as if real analysis tools were run.
Return the complete risk assessment in the required JSON format."""
        return self._call(prompt)

    def _call(self, prompt: str) -> dict:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": prompt},
            ],
            temperature=0.3,
            max_tokens=1200,
        )
        raw = response.choices[0].message.content or ""
        return self._parse(raw)

    def _parse(self, raw: str) -> dict:
        clean = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
        try:
            return json.loads(clean)
        except json.JSONDecodeError:
            pass
        m = re.search(r"\{.*\}", clean, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
        return {
            "verdict": "SUSPICIOUS", "confidence": 50, "riskScore": 50,
            "threatType": "Analysis Error",
            "signals": [{"label": "Parse Error",
                          "value": "Could not parse AI response. Please retry.",
                          "severity": "medium"}],
            "summary": "The analysis engine returned an unexpected response. Please retry.",
            "recommendation": "Retry the scan. Verify your Groq API key at console.groq.com.",
            "reportToPortal": False,
        }
