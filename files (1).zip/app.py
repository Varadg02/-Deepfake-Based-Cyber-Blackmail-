"""
DeepShield — Streamlit Frontend
Powered by Groq API (FREE) — llama-3.3-70b-versatile

Setup:
  pip install -r requirements.txt
  streamlit run app.py
"""

import streamlit as st
import time, os
from agent import DeepShieldAgent
from report import generate_pdf_report

st.set_page_config(
    page_title="DeepShield | Deepfake Threat Detection",
    page_icon="🛡️", layout="wide",
    initial_sidebar_state="collapsed",
)

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Exo+2:wght@700;900&display=swap');
html,body,[class*="css"]{ background:#040810 !important; color:#E2E8F0; font-family:'Share Tech Mono',monospace; }
.main{ background:#040810 !important; }
.block-container{ padding-top:1.5rem; max-width:1000px; }
.ds-header{ display:flex; align-items:center; gap:14px; padding:12px 0 26px; border-bottom:1px solid rgba(0,255,136,.15); margin-bottom:26px; }
.ds-logo{ width:44px; height:44px; background:linear-gradient(135deg,#00FF88,#00D4FF); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px; box-shadow:0 0 20px rgba(0,255,136,.4); }
.ds-brand{ font-size:24px; font-weight:900; letter-spacing:6px; color:#00FF88; font-family:'Exo 2',sans-serif; }
.ds-sub{ font-size:9px; color:#334155; letter-spacing:3px; }
.ds-pill{ margin-left:auto; background:rgba(0,255,136,.07); border:1px solid rgba(0,255,136,.2); border-radius:20px; padding:5px 13px; font-size:10px; color:#00FF88; letter-spacing:2px; }
.card{ background:rgba(255,255,255,.02); border:1px solid rgba(255,255,255,.07); border-radius:14px; padding:22px; margin-bottom:14px; }
.clabel{ font-size:10px; letter-spacing:3px; color:#475569; margin-bottom:12px; text-transform:uppercase; }
.vd{ display:inline-block; padding:9px 26px; border-radius:40px; font-size:17px; font-weight:900; letter-spacing:4px; }
.vd-DEEPFAKE  { background:rgba(255,59,92,.12);  border:1px solid rgba(255,59,92,.4);  color:#FF3B5C; box-shadow:0 0 20px rgba(255,59,92,.2); }
.vd-SUSPICIOUS{ background:rgba(255,149,0,.12);  border:1px solid rgba(255,149,0,.4);  color:#FF9500; box-shadow:0 0 20px rgba(255,149,0,.2); }
.vd-SAFE      { background:rgba(0,255,136,.12);  border:1px solid rgba(0,255,136,.4);  color:#00FF88; box-shadow:0 0 20px rgba(0,255,136,.2); }
.sig-row{ display:flex; align-items:center; gap:12px; padding:9px 0; border-bottom:1px solid rgba(255,255,255,.04); font-size:12px; }
.sb{ padding:2px 8px; border-radius:10px; font-size:10px; }
.sb-high  { background:rgba(255,59,92,.1);  color:#FF3B5C; }
.sb-medium{ background:rgba(255,149,0,.1);  color:#FF9500; }
.sb-low   { background:rgba(0,255,136,.1);  color:#00FF88; }
.rec-box{ background:rgba(99,102,241,.07); border:1px solid rgba(99,102,241,.2); border-radius:10px; padding:14px 18px; font-size:13px; color:#94A3B8; line-height:1.7; }
.alert-box{ background:rgba(255,59,92,.08); border:1px solid rgba(255,59,92,.25); border-radius:10px; padding:10px; color:#FF3B5C; font-size:11px; text-align:center; margin-top:10px; }
.stat-box{ background:rgba(255,255,255,.02); border:1px solid rgba(255,255,255,.06); border-radius:10px; padding:14px; text-align:center; }
.sv{ font-size:26px; font-weight:900; color:#00FF88; letter-spacing:2px; }
.sl{ font-size:10px; color:#334155; letter-spacing:1px; margin-top:3px; }
.uhint{ text-align:center; padding:5px 0; color:#334155; font-size:11px; letter-spacing:2px; }
#MainMenu,footer,header{ visibility:hidden; }
.stDeployButton{ display:none; }
.stButton>button{ background:linear-gradient(135deg,#00FF88,#00D4FF) !important; color:#040810 !important; border:none !important; font-family:'Share Tech Mono',monospace !important; font-weight:900 !important; letter-spacing:3px !important; font-size:13px !important; padding:13px 38px !important; border-radius:10px !important; box-shadow:0 0 24px rgba(0,255,136,.25) !important; width:100% !important; }
.stButton>button:hover{ box-shadow:0 0 40px rgba(0,255,136,.45) !important; }
.stProgress>div>div{ background:linear-gradient(90deg,#00FF88,#00D4FF) !important; }
.stTextArea textarea{ background:rgba(255,255,255,.02) !important; border:1px solid rgba(255,255,255,.1) !important; color:#E2E8F0 !important; font-family:'Share Tech Mono',monospace !important; font-size:13px !important; border-radius:10px !important; }
[data-testid="stFileUploaderDropzone"]{ background:rgba(255,255,255,.01) !important; border:2px dashed rgba(255,255,255,.12) !important; border-radius:12px !important; }
.stTabs [data-baseweb="tab-list"]{ background:transparent !important; gap:8px; }
.stTabs [data-baseweb="tab"]{ background:rgba(255,255,255,.02) !important; border:1px solid rgba(255,255,255,.08) !important; border-radius:6px !important; color:#475569 !important; font-family:'Share Tech Mono',monospace !important; font-size:11px !important; letter-spacing:2px !important; }
.stTabs [aria-selected="true"]{ background:rgba(0,255,136,.1) !important; border-color:#00FF88 !important; color:#00FF88 !important; }
.stTabs [data-baseweb="tab-highlight"],.stTabs [data-baseweb="tab-border"]{ display:none !important; }
[data-testid="stMetricValue"]{ color:#00FF88 !important; }
</style>
""", unsafe_allow_html=True)

# ── Session State ──────────────────────────────────────────────────────────────
for k, v in [("history", []), ("result", None), ("groq_key", os.getenv("GROQ_API_KEY", ""))]:
    if k not in st.session_state:
        st.session_state[k] = v

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="ds-header">
  <div class="ds-logo">🛡️</div>
  <div><div class="ds-brand">DEEPSHIELD</div><div class="ds-sub">AGENTIC DEEPFAKE THREAT DETECTION SYSTEM</div></div>
  <div class="ds-pill">● SYSTEM ONLINE</div>
</div>""", unsafe_allow_html=True)

# ── API Key Gate ───────────────────────────────────────────────────────────────
if not st.session_state.groq_key:
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.markdown('<div class="clabel">🔑 API CONFIGURATION</div>', unsafe_allow_html=True)
    st.markdown("""<div style="font-size:13px;color:#94A3B8;margin-bottom:12px;line-height:1.9;">
        DeepShield uses the <b style="color:#00FF88;">Groq API</b> — 100% free, no credit card needed.<br/>
        Get your key: <a href="https://console.groq.com" target="_blank" style="color:#00D4FF;">console.groq.com</a>
        → Login → API Keys → Create API Key
    </div>""", unsafe_allow_html=True)
    k = st.text_input("Groq API Key", type="password",
                       placeholder="gsk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                       label_visibility="collapsed")
    st.caption("🔒 Stored in session memory only — never written to disk.")
    st.markdown('</div>', unsafe_allow_html=True)
    if k.strip():
        st.session_state.groq_key = k.strip()
        st.rerun()
    st.stop()

# ── Tabs ───────────────────────────────────────────────────────────────────────
t_scan, t_hist, t_about = st.tabs([
    "⚡  SCAN",
    f"📋  HISTORY  ({len(st.session_state.history)})",
    "ℹ️   ABOUT",
])

# ══════════════════════════════════════════════════════════════════════════════
# SCAN TAB
# ══════════════════════════════════════════════════════════════════════════════
with t_scan:

    if not st.session_state.result:
        st.markdown("""
        <div style="text-align:center;padding:14px 0 30px;">
          <div style="font-size:10px;letter-spacing:5px;color:#00FF88;margin-bottom:10px;opacity:.7;">AI-POWERED FORENSIC ANALYSIS</div>
          <h1 style="font-size:clamp(24px,4vw,42px);font-weight:900;line-height:1.15;
              background:linear-gradient(135deg,#E2E8F0 30%,#00FF88);
              -webkit-background-clip:text;-webkit-text-fill-color:transparent;
              font-family:'Exo 2',sans-serif;margin:0 0 10px;">
              Detect Deepfakes.<br/>Stop Cyber Blackmail.
          </h1>
          <p style="color:#475569;font-size:13px;max-width:420px;margin:0 auto;line-height:1.9;">
              Upload any image, video, or audio — our agentic AI pipeline analyzes it
              for synthetic manipulation and cyber threat patterns in seconds.
          </p>
        </div>""", unsafe_allow_html=True)

    if not st.session_state.result:
        mode = st.radio("Mode", ["📁  Upload File", "📝  Paste Text / URL"],
                        horizontal=True, label_visibility="collapsed")
        st.markdown("---")

        uploaded_file = None
        text_input = ""

        if "Upload" in mode:
            uploaded_file = st.file_uploader("File",
                type=["jpg","jpeg","png","webp","mp4","mov","mp3","wav","ogg","m4a"],
                label_visibility="collapsed")
            st.markdown('<div class="uhint">JPG · PNG · WEBP · MP4 · MOV · MP3 · WAV · M4A</div>',
                        unsafe_allow_html=True)
            if uploaded_file and uploaded_file.type.startswith("image/"):
                st.image(uploaded_file, width=360)
        else:
            text_input = st.text_area("Text", height=150, label_visibility="collapsed",
                placeholder="Paste a threatening message, blackmail text, or URL...\n\nExample: 'I have AI-generated videos of you. Pay money or I will share them with your contacts.'")

        st.markdown("<br/>", unsafe_allow_html=True)
        can_scan = (uploaded_file is not None) or bool(text_input.strip())

        if can_scan and st.button("⚡  RUN THREAT ANALYSIS", use_container_width=True):
            st.markdown('<div style="text-align:center;padding:6px 0 2px;"><span style="font-size:11px;letter-spacing:3px;color:#00FF88;">ANALYZING...</span></div>', unsafe_allow_html=True)
            pb = st.progress(0)
            st_txt = st.empty()
            for p, m in [(0.15,"🔬 Extracting media fingerprint..."),(0.35,"🧬 Running deepfake detection model..."),(0.55,"👁️  Analyzing artifacts & GAN traces..."),(0.75,"🤖 Invoking threat reasoning agent..."),(0.92,"📊 Generating forensic report..."),(1.0,"✅ Analysis complete.")]:
                pb.progress(p)
                st_txt.markdown(f'<div style="text-align:center;color:#64748B;font-size:12px;letter-spacing:1px;">{m}</div>', unsafe_allow_html=True)
                time.sleep(0.55)

            agent = DeepShieldAgent(api_key=st.session_state.groq_key)
            try:
                if uploaded_file:
                    result = agent.analyze_file(uploaded_file.read(), uploaded_file.name, uploaded_file.type)
                else:
                    result = agent.analyze_text(text_input.strip())
                st.session_state.result = result
                st.session_state.history.append({
                    "id": int(time.time()),
                    "name": uploaded_file.name if uploaded_file else text_input[:50]+"...",
                    "time": time.strftime("%H:%M:%S"),
                    "result": result,
                })
                st.rerun()
            except Exception as e:
                st.error(f"⚠️ Analysis failed: {e}")

    # Results
    if st.session_state.result:
        r = st.session_state.result
        c, _ = st.columns([1, 5])
        with c:
            if st.button("← NEW SCAN"):
                st.session_state.result = None
                st.rerun()
        st.markdown("<br/>", unsafe_allow_html=True)

        verdict    = r.get("verdict","SUSPICIOUS")
        confidence = r.get("confidence", 50)
        risk       = r.get("riskScore", 50)
        ttype      = r.get("threatType","Unknown")
        summary    = r.get("summary","")
        rec        = r.get("recommendation","")
        signals    = r.get("signals",[])
        flag       = r.get("reportToPortal", False)
        rc         = "#FF3B5C" if risk >= 70 else "#FF9500" if risk >= 40 else "#00FF88"
        cc         = "#00FF88" if confidence >= 70 else "#FF9500" if confidence >= 40 else "#FF3B5C"

        col1, col2 = st.columns(2)
        with col1:
            st.markdown(f"""<div class="card" style="min-height:255px;">
              <div class="clabel">VERDICT</div>
              <div style="text-align:center;padding:8px 0;">
                <div class="vd vd-{verdict}">{verdict}</div>
                <div style="margin-top:10px;font-size:12px;color:#64748B;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:6px 12px;display:inline-block;">{ttype}</div>
                <div style="margin-top:12px;font-size:12px;color:#94A3B8;line-height:1.8;">{summary}</div>
              </div></div>""", unsafe_allow_html=True)

        with col2:
            st.markdown(f"""<div class="card" style="min-height:255px;">
              <div class="clabel">RISK SCORE</div>
              <div style="text-align:center;">
                <div style="font-size:66px;font-weight:900;color:{rc};line-height:1;font-family:'Exo 2',sans-serif;text-shadow:0 0 28px {rc}55;">{risk}</div>
                <div style="font-size:10px;color:#475569;letter-spacing:2px;">/&nbsp;100</div>
                <div style="margin-top:16px;margin-bottom:4px;display:flex;justify-content:space-between;font-size:11px;">
                  <span style="color:#475569;">AI CONFIDENCE</span><span style="color:{cc};">{confidence}%</span>
                </div>
                <div style="height:6px;background:rgba(255,255,255,.05);border-radius:3px;">
                  <div style="height:100%;width:{confidence}%;background:linear-gradient(90deg,#00FF88,#00D4FF);border-radius:3px;"></div>
                </div>
                {"<div class='alert-box'>⚠ REPORT TO CYBERCRIME PORTAL RECOMMENDED</div>" if flag else ""}
              </div></div>""", unsafe_allow_html=True)

        st.markdown("<br/>", unsafe_allow_html=True)

        if signals:
            st.markdown('<div class="card"><div class="clabel">🔬 FORENSIC SIGNALS</div>', unsafe_allow_html=True)
            for s in signals:
                sev = s.get("severity","low").lower()
                dc  = "#FF3B5C" if sev=="high" else "#FF9500" if sev=="medium" else "#00FF88"
                st.markdown(f"""<div class="sig-row">
                  <span style="color:{dc};font-size:9px;">◆</span>
                  <div style="flex:1;">
                    <div style="font-size:10px;color:#64748B;letter-spacing:1px;">{s.get("label","")}</div>
                    <div style="font-size:12px;color:#E2E8F0;margin-top:2px;">{s.get("value","")}</div>
                  </div>
                  <span class="sb sb-{sev if sev in ['high','medium','low'] else 'low'}">{sev.upper()}</span>
                </div>""", unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

        if rec:
            st.markdown(f'<div style="margin-bottom:12px;"><div class="clabel">💡 RECOMMENDED ACTION</div><div class="rec-box">{rec}</div></div>', unsafe_allow_html=True)

        if flag:
            st.markdown("""<div class="card" style="border-color:rgba(255,59,92,.25);">
              <div class="clabel" style="color:#FF3B5C;">🚨 CYBERCRIME REPORTING</div>
              <div style="font-size:12px;color:#94A3B8;line-height:2.2;">
                🇮🇳 <b style="color:#E2E8F0;">India</b> — cybercrime.gov.in &nbsp;|&nbsp; Helpline: <b style="color:#00FF88;">1930</b><br/>
                🇺🇸 <b style="color:#E2E8F0;">USA</b> — ic3.gov (FBI)<br/>
                🌍 <b style="color:#E2E8F0;">International</b> — interpol.int/en/Crimes/Cybercrime
              </div></div>""", unsafe_allow_html=True)

        st.markdown('<div class="clabel">📄 EVIDENCE EXPORT</div>', unsafe_allow_html=True)
        try:
            pdf = generate_pdf_report(r)
            st.download_button("⬇  DOWNLOAD PDF EVIDENCE REPORT", data=pdf,
                               file_name=f"deepshield_{int(time.time())}.pdf",
                               mime="application/pdf", use_container_width=True)
        except Exception as e:
            st.warning(f"PDF unavailable: {e}  →  pip install reportlab")

    if not st.session_state.result:
        h = st.session_state.history
        st.markdown("<br/><br/>", unsafe_allow_html=True)
        c1,c2,c3 = st.columns(3)
        df  = sum(1 for x in h if x["result"].get("verdict")=="DEEPFAKE")
        avg = int(sum(x["result"].get("riskScore",0) for x in h)/len(h)) if h else 0
        with c1: st.markdown(f'<div class="stat-box"><div class="sv">{len(h):03d}</div><div class="sl">SCANS TODAY</div></div>', unsafe_allow_html=True)
        with c2: st.markdown(f'<div class="stat-box"><div class="sv">{df:03d}</div><div class="sl">DEEPFAKES FOUND</div></div>', unsafe_allow_html=True)
        with c3: st.markdown(f'<div class="stat-box"><div class="sv">{"---" if not h else avg}</div><div class="sl">AVG RISK SCORE</div></div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# HISTORY TAB
# ══════════════════════════════════════════════════════════════════════════════
with t_hist:
    if not st.session_state.history:
        st.markdown('<div style="text-align:center;padding:60px 0;color:#334155;font-size:13px;">No scans yet. Go to the Scan tab to analyze media.</div>', unsafe_allow_html=True)
    else:
        for item in reversed(st.session_state.history):
            r = item["result"]
            with st.expander(f"[{item['time']}]  {item['name'][:55]}  —  Risk: {r.get('riskScore',0)}/100"):
                m1,m2,m3 = st.columns(3)
                m1.metric("Verdict",   r.get("verdict","?"))
                m2.metric("Risk",      f"{r.get('riskScore',0)}/100")
                m3.metric("Confidence",f"{r.get('confidence',0)}%")
                st.write(f"**Threat:** {r.get('threatType','')}")
                st.write(f"**Summary:** {r.get('summary','')}")
                st.write(f"**Action:** {r.get('recommendation','')}")

# ══════════════════════════════════════════════════════════════════════════════
# ABOUT TAB
# ══════════════════════════════════════════════════════════════════════════════
with t_about:
    st.markdown("""
    <div class="card">
      <div class="clabel">ABOUT DEEPSHIELD</div>
      <p style="color:#94A3B8;line-height:1.9;font-size:13px;">
        DeepShield is an agentic AI platform detecting deepfake media and cyber blackmail threats.
        It combines forensic metadata analysis with LLM reasoning (Groq llama-3.3-70b — free) to
        produce actionable threat intelligence reports and downloadable PDF evidence.
      </p>
    </div>
    <div class="card">
      <div class="clabel">PIPELINE</div>
      <div style="font-size:12px;color:#64748B;line-height:2.6;">
        <span style="color:#00FF88;">01</span>&nbsp;&nbsp;Media ingestion + Pillow metadata extraction<br/>
        <span style="color:#FF6B35;">02</span>&nbsp;&nbsp;EXIF analysis — absence = AI generation indicator<br/>
        <span style="color:#A855F7;">03</span>&nbsp;&nbsp;Groq llama-3.3-70b agentic forensic reasoning<br/>
        <span style="color:#F59E0B;">04</span>&nbsp;&nbsp;Risk score + threat classification<br/>
        <span style="color:#10B981;">05</span>&nbsp;&nbsp;PDF evidence report (ReportLab)
      </div>
    </div>
    <div class="card">
      <div class="clabel">FREE GROQ KEY SETUP</div>
      <div style="font-size:12px;color:#64748B;line-height:2.4;">
        1. Go to <a href="https://console.groq.com" target="_blank" style="color:#00D4FF;">console.groq.com</a><br/>
        2. Sign up / Login (GitHub works)<br/>
        3. API Keys → Create API Key<br/>
        4. Copy your <code style="color:#00FF88;">gsk_...</code> key and paste it in the app
      </div>
    </div>
    <div class="card">
      <div class="clabel">DEPLOY FREE</div>
      <div style="font-size:12px;color:#64748B;line-height:2.4;">
        1. Push this folder to GitHub<br/>
        2. <a href="https://share.streamlit.io" target="_blank" style="color:#00D4FF;">share.streamlit.io</a> → New app → Select app.py<br/>
        3. Add <code style="color:#00FF88;">GROQ_API_KEY</code> in Secrets → Deploy ✅
      </div>
    </div>""", unsafe_allow_html=True)
