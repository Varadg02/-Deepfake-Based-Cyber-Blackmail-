# 🛡️ DeepShield — Agentic Deepfake Threat Detection

Detects AI-generated deepfake media and cyber blackmail threats.
Powered by **Groq API** (free) — llama-3.3-70b-versatile.

---

## 📁 Files

```
deepshield_app/
├── app.py              ← Streamlit UI
├── agent.py            ← Groq AI analysis engine
├── report.py           ← PDF evidence report generator
├── requirements.txt    ← Dependencies
└── README.md
```

---

## ⚡ Quick Start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Run
streamlit run app.py
```

Open http://localhost:8501 — paste your free Groq key when prompted.

---

## 🔑 Get Free Groq API Key

1. Go to https://console.groq.com
2. Login (GitHub works)
3. API Keys → Create API Key
4. Copy key starting with `gsk_...`
5. Paste into the app → done ✅

No credit card. No billing. Completely free.

---

## 🌐 Deploy Free (Streamlit Cloud)

1. Push folder to GitHub
2. share.streamlit.io → New app → select app.py
3. Secrets: add `GROQ_API_KEY = "gsk_..."`
4. Deploy → live URL in ~2 minutes ✅

---

## 🔄 Switching back to Anthropic Claude

If you later get Anthropic credits, change in `agent.py`:
- Replace `from groq import Groq` with `from anthropic import Anthropic`
- Replace `Groq(api_key=...)` with `Anthropic(api_key=...)`
- Use `client.messages.create(model="claude-sonnet-4-20250514", ...)`
