"""
DeepShield v2 — V-JEPA Deepfake Video Detector
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Architecture:
  Frozen V-JEPA ViT-H encoder  →  AttentiveProbe  →  Binary classifier
                 (never trained)      (trained)        real / deepfake

Why V-JEPA for deepfake detection?
  V-JEPA learns rich spatio-temporal representations by predicting masked
  video patches in latent space. Deepfakes introduce temporal inconsistencies
  (blink suppression, micro-expression gaps, boundary flicker) that V-JEPA
  features capture well — far better than single-frame models.

Weights:
  • V-JEPA encoder: https://github.com/facebookresearch/jepa (vit_h_16_224.pth ~2.4 GB)
  • Probe:          train_probe() on FaceForensics++ / DFDC (deepshield_probe.pth)
"""

import os
import tempfile
import numpy as np
import torch
import torch.nn as nn


# ══════════════════════════════════════════════════════════════════════════════
# ATTENTIVE PROBE
# ══════════════════════════════════════════════════════════════════════════════
class AttentiveProbe(nn.Module):
    """
    Lightweight attention-based binary probe on top of frozen V-JEPA features.
    Only this module is trained — the V-JEPA encoder stays completely frozen.

    Architecture:
        Learnable query → Multi-Head Cross-Attention over all tokens
        → LayerNorm → 2-layer MLP → [real_logit, fake_logit]

    Why attention instead of mean-pool?
        Deepfake artifacts are spatially localized (face region, boundaries).
        Attention learns to focus on the most diagnostic tokens rather than
        averaging over background regions.
    """

    def __init__(self, embed_dim: int = 1280, num_heads: int = 8, dropout: float = 0.3):
        super().__init__()
        self.query = nn.Parameter(torch.randn(1, 1, embed_dim) * 0.02)
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=embed_dim, num_heads=num_heads,
            dropout=dropout, batch_first=True,
        )
        self.norm1 = nn.LayerNorm(embed_dim)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, 512),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(512, 128),
            nn.GELU(),
            nn.Dropout(dropout * 0.5),
            nn.Linear(128, 2),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        """
        Args:   features [B, N_tokens, embed_dim]
        Returns: logits  [B, 2]
        """
        B = features.shape[0]
        query = self.query.expand(B, -1, -1)
        attended, _ = self.cross_attn(query, features, features)
        pooled = self.norm1(attended.squeeze(1))
        return self.mlp(pooled)


# ══════════════════════════════════════════════════════════════════════════════
# FULL DETECTOR PIPELINE
# ══════════════════════════════════════════════════════════════════════════════
class VJEPADeepfakeDetector:
    """Full pipeline: video bytes → V-JEPA features → binary prediction."""

    MEAN        = np.array([0.485, 0.456, 0.406], dtype=np.float32)
    STD         = np.array([0.229, 0.224, 0.225], dtype=np.float32)
    FRAME_SIZE  = 224
    NUM_FRAMES  = 16

    def __init__(self, encoder_weights: str, probe_weights: str = None, device: str = "cpu"):
        self.device = torch.device(device)

        # Load frozen V-JEPA ViT-H encoder
        # Requires jepa repo: git clone https://github.com/facebookresearch/jepa
        from src.models.vision_transformer import vit_huge
        self.encoder = vit_huge(patch_size=16, num_frames=self.NUM_FRAMES, img_size=self.FRAME_SIZE)
        ckpt = torch.load(encoder_weights, map_location=self.device)
        state_dict = ckpt.get("encoder", ckpt)
        self.encoder.load_state_dict(state_dict, strict=False)
        self.encoder = self.encoder.to(self.device).eval()
        for p in self.encoder.parameters():
            p.requires_grad = False  # FROZEN — never updated

        # Attentive probe (trainable)
        self.probe = AttentiveProbe(embed_dim=1280, num_heads=8).to(self.device)
        if probe_weights and os.path.exists(probe_weights):
            self.probe.load_state_dict(torch.load(probe_weights, map_location=self.device))
        self.probe.eval()

    def predict(self, video_bytes: bytes) -> dict:
        """Run full deepfake detection on raw video bytes."""
        frames = self._extract_frames(video_bytes, self.NUM_FRAMES)
        if not frames:
            return {"verdict": "REAL", "deepfake_prob": 0.0, "real_prob": 100.0,
                    "confidence": 0.0, "frames_analyzed": 0, "source": "vjepa_real",
                    "error": "No frames extracted."}

        tensor = self._preprocess(frames)
        with torch.no_grad():
            features = self.encoder(tensor)      # [1, N_tokens, 1280]
            logits   = self.probe(features)      # [1, 2]
            probs    = torch.softmax(logits, -1)

        real_prob  = float(probs[0, 0])
        fake_prob  = float(probs[0, 1])
        verdict    = "DEEPFAKE" if fake_prob > 0.5 else "REAL"
        confidence = round(max(real_prob, fake_prob) * 100, 1)

        return {
            "verdict":         verdict,
            "deepfake_prob":   round(fake_prob * 100, 1),
            "real_prob":       round(real_prob * 100, 1),
            "confidence":      confidence,
            "frames_analyzed": len(frames),
            "source":          "vjepa_real",
        }

    def _extract_frames(self, video_bytes: bytes, num_frames: int) -> list:
        import cv2
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
            tmp.write(video_bytes)
            tmp_path = tmp.name
        try:
            cap   = cv2.VideoCapture(tmp_path)
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            if total == 0:
                cap.release()
                return []
            indices = np.linspace(0, total - 1, num_frames, dtype=int)
            frames  = []
            for idx in indices:
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx))
                ret, frame = cap.read()
                if ret:
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    frame = cv2.resize(frame, (self.FRAME_SIZE, self.FRAME_SIZE))
                    frames.append(frame)
            cap.release()
        finally:
            os.unlink(tmp_path)
        return frames

    def _preprocess(self, frames: list) -> torch.Tensor:
        processed = [(f.astype(np.float32) / 255.0 - self.MEAN) / self.STD for f in frames]
        arr = np.stack(processed).transpose(3, 0, 1, 2)   # [3, T, H, W]
        return torch.from_numpy(arr).unsqueeze(0).to(self.device)

    def train_probe(self, train_loader, val_loader=None, epochs: int = 10,
                    lr: float = 1e-4, save_path: str = "deepshield_probe.pth"):
        """
        Train only the AttentiveProbe — encoder stays frozen.

        train_loader: yields (video_tensor [B,3,T,H,W], label [B])  label: 0=real 1=fake
        Recommended datasets: FaceForensics++, DFDC, Celeb-DF v2
        """
        optimizer = torch.optim.AdamW(self.probe.parameters(), lr=lr, weight_decay=1e-4)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
        criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
        best_val  = 0.0

        for epoch in range(epochs):
            self.probe.train()
            total_loss, correct, total = 0.0, 0, 0
            for videos, labels in train_loader:
                videos, labels = videos.to(self.device), labels.to(self.device)
                with torch.no_grad():
                    features = self.encoder(videos)
                logits = self.probe(features)
                loss   = criterion(logits, labels)
                optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.probe.parameters(), 1.0)
                optimizer.step()
                total_loss += loss.item()
                correct    += (logits.argmax(1) == labels).sum().item()
                total      += labels.size(0)
            scheduler.step()
            acc = correct / total * 100
            print(f"Epoch {epoch+1:02d}/{epochs}  loss={total_loss/len(train_loader):.4f}  acc={acc:.1f}%", end="")
            if val_loader:
                self.probe.eval()
                vc, vt = 0, 0
                with torch.no_grad():
                    for vv, vl in val_loader:
                        vv, vl = vv.to(self.device), vl.to(self.device)
                        vf  = self.encoder(vv)
                        vlo = self.probe(vf)
                        vc += (vlo.argmax(1) == vl).sum().item()
                        vt += vl.size(0)
                val_acc = vc / vt * 100
                print(f"  val_acc={val_acc:.1f}%", end="")
                if val_acc > best_val:
                    best_val = val_acc
                    torch.save(self.probe.state_dict(), save_path)
                    print("  ✓ saved", end="")
            else:
                torch.save(self.probe.state_dict(), save_path)
            print()
        print(f"[V-JEPA] Probe training complete → {save_path}")
