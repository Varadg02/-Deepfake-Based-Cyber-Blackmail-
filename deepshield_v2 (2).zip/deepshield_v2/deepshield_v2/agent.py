"""
DeepShield -- Agentic Analysis Engine v2
==========================================

Two-stage pipeline
------------------

  STAGE 1 -- Groq LLM (llama-3.3-70b-versatile)      <-- BASE DETECTION
  +-----------------------------------------------------------------+
  |  Primary forensic reasoning engine.                             |
  |  Input : EXIF metadata, dimensions, filename, file size,        |
  |           codec info, audio features, text content.             |
  |  Output: verdict, riskScore, confidence, signals, summary.      |
  +-----------------------------------------------------------------+
                              |
  STAGE 2 -- VL-JEPA (ViT-Huge frozen + AttentiveProbe) <-- VERIFICATION
  +-----------------------------------------------------------------+
  |  Visual/temporal verification layer for images and video.       |
  |  Extracts self-supervised spatio-temporal features from frozen   |
  |  ViT-Huge backbone; classifies with a lightweight binary probe. |
  |  Output: deepfake_prob, real_prob, confidence, verdict.         |
  |  Skipped for: audio, plain text (not applicable).               |
  +-----------------------------------------------------------------+
                              |
  STAGE 3 -- Fusion (confidence-weighted reconciliation)
  +-----------------------------------------------------------------+
  |  - VL-JEPA unavailable       -> Groq result + note              |
  |  - Both agree                -> +8 pts confidence, merge sigs   |
  |  - VL-JEPA fake_prob > 72%   -> escalate to DEEPFAKE            |
  |  - VL-JEPA fake_prob < 25%   -> de-escalate SUSPICIOUS -> SAFE  |
  |  - Otherwise                 -> take higher-risk verdict         |
  |  - riskScore = 0.55*groq + 0.45*vjepa                          |
  +-----------------------------------------------------------------+
"""

import json
import re
import io
from groq import Groq
from vjepa_detector import VJEPADeepfakeDetector

# ---------------------------------------------------------------------------
# SYSTEM PROMPT (Groq Stage-1)
# ---------------------------------------------------------------------------
_SYSTEM = """You are DeepShield's primary forensic AI -- an expert in detecting deepfake media
and cyber blackmail threats.

You are STAGE-1 of a two-stage pipeline. A separate VL-JEPA visual encoder
independently verifies your verdict on images/video in Stage-2. The two verdicts
are fused with a confidence-weighted rule engine.

Your job: analyse metadata, filename patterns, structural signals, and content
to produce an accurate first-pass forensic verdict.

IMPORTANT -- be balanced: NOT everything is suspicious.
- Screenshots and social-media images naturally lack EXIF -- this alone proves nothing.
- Only return DEEPFAKE when there is clear, convergent evidence of AI generation.
- Only return SUSPICIOUS for moderate, multi-signal concerns.

Respond ONLY in this exact JSON format (raw JSON, no markdown, no preamble):
{
  "verdict":        "DEEPFAKE" | "SUSPICIOUS" | "SAFE",
  "confidence":     <integer 0-100>,
  "riskScore":      <integer 0-100>,
  "threatType":     "Cyber Blackmail" | "AI-Generated Face" | "Cloned Audio" | "Synthetic Video" | "Phishing Link" | "Safe Content" | "Suspicious Content",
  "signals": [
    { "label": "<name>", "value": "<detailed finding>", "severity": "high" | "medium" | "low" }
  ],
  "summary":        "<2-3 sentence human-readable explanation>",
  "recommendation": "<1-2 sentence action for the victim>",
  "reportToPortal": <true | false>
}

Rules:
- Return exactly 4-6 forensic signals
- Set reportToPortal=true when verdict is DEEPFAKE or riskScore >= 70
- Return ONLY valid JSON -- no text outside the JSON object
"""


# ---------------------------------------------------------------------------
# FUSION ENGINE (Stage 3)
# ---------------------------------------------------------------------------

def _vrank(v):
    return {"SAFE": 0, "SUSPICIOUS": 1, "DEEPFAKE": 2}.get(str(v).upper(), 1)

def _rank_v(r):
    return {0: "SAFE", 1: "SUSPICIOUS", 2: "DEEPFAKE"}[max(0, min(2, r))]


def fuse(groq_r, vjepa_r):
    """
    Merge Groq (Stage-1) and VL-JEPA (Stage-2) results into one
    authoritative forensic verdict.
    """
    # VL-JEPA not available (audio / text / no weights)
    if vjepa_r is None:
        groq_r["pipeline"]          = "groq-only"
        groq_r["verificationLayer"] = "VL-JEPA not applicable for this media type"
        groq_r["verdictAgreement"]  = None
        return groq_r

    fp     = vjepa_r.get("deepfake_prob", 50.0) / 100.0
    g_rank = _vrank(groq_r.get("verdict", "SUSPICIOUS"))
    v_rank = 2 if fp >= 0.72 else (1 if fp >= 0.42 else 0)
    agreed = (g_rank == v_rank)

    # Fusion verdict rule
    if agreed:
        final_rank = g_rank
    elif fp > 0.72 and g_rank < 2:
        final_rank = 2   # VL-JEPA strongly says fake -- visual evidence overrides
    elif fp < 0.25 and g_rank == 1:
        final_rank = 0   # VL-JEPA clearly real, Groq only suspicious -> de-escalate
    else:
        final_rank = max(g_rank, v_rank)

    g_risk = groq_r.get("riskScore", 50)
    g_conf = groq_r.get("confidence", 50)
    v_conf = vjepa_r.get("confidence", 50)
    f_risk = round(0.55 * g_risk + 0.45 * (fp * 100))
    f_conf = (min(99, round((g_conf + v_conf) / 2 + 8))
              if agreed else round((g_conf + v_conf) / 2))
    f_verd = _rank_v(final_rank)

    sev = "high" if fp > 0.65 else ("medium" if fp > 0.35 else "low")
    mode_tag = vjepa_r.get("mode", "live")
    vjepa_signal = {
        "label": "VL-JEPA Visual Verification",
        "value": (
            f"[{mode_tag.upper()}] Spatio-temporal ViT-Huge encoder -- "
            f"fake_prob={vjepa_r['deepfake_prob']}%  "
            f"real_prob={vjepa_r['real_prob']}%  "
            f"frames={vjepa_r.get('frames_analyzed', '-')}  "
            f"verdict={vjepa_r['verdict']}  "
            f"model={vjepa_r.get('model', 'VL-JEPA')}"
        ),
        "severity": sev,
    }

    return {
        **groq_r,
        "verdict":          f_verd,
        "confidence":       f_conf,
        "riskScore":        f_risk,
        "reportToPortal":   f_verd == "DEEPFAKE" or f_risk >= 70,
        "signals":          (groq_r.get("signals") or []) + [vjepa_signal],
        "pipeline":         "groq-primary + vl-jepa-verification",
        "verificationLayer": f"VL-JEPA ViT-Huge (frozen) + AttentiveProbe [{mode_tag}]",
        "groqVerdict":      groq_r.get("verdict"),
        "vjepaVerdict":     vjepa_r["verdict"],
        "vjepFakeProb":     vjepa_r["deepfake_prob"],
        "verdictAgreement": agreed,
    }


# ---------------------------------------------------------------------------
# MAIN AGENT
# ---------------------------------------------------------------------------

class DeepShieldAgent:
    """
    Two-stage deepfake + cyber blackmail detection agent.

    Usage
    -----
        agent = DeepShieldAgent(
            api_key="gsk_...",
            vjepa_encoder_weights="vith14.pth",          # optional
            vjepa_probe_weights="deepshield_probe.pth",  # optional
        )
        result = agent.analyze_file(file_bytes, "vid.mp4", "video/mp4")
        result = agent.analyze_text("Pay or I release the video...")
    """

    MODEL = "llama-3.3-70b-versatile"

    def __init__(self, api_key,
                 vjepa_encoder_weights=None,
                 vjepa_probe_weights=None,
                 device="cpu"):
        # Stage 1 -- Groq LLM (base detection)
        self.groq = Groq(api_key=api_key)

        # Stage 2 -- VL-JEPA (verification; degrades to simulation if no weights)
        self.vjepa = VJEPADeepfakeDetector(
            encoder_weights=vjepa_encoder_weights,
            probe_weights=vjepa_probe_weights,
            device=device,
        )

    # -- Public API ----------------------------------------------------------

    def analyze_file(self, file_bytes, file_name, file_type):
        if file_type.startswith("image/"):
            return self._image(file_bytes, file_type, file_name)
        if file_type.startswith("video/"):
            return self._video(file_bytes, file_name, file_type)
        if file_type.startswith("audio/"):
            return self._audio(file_name, file_type)
        return self._generic(file_name, file_type)

    def analyze_text(self, text):
        prompt = f"""Analyze this message for deepfake-based cyber blackmail, threats, or phishing.

CONTENT:
\"\"\"{text}\"\"\"

Evaluate for:
- Threatening / extortionate language
- Claims of possessing AI-generated compromising media
- Demands for money, silence, or personal favors
- Urgency manipulation tactics
- Suspicious media-hosting URLs
- Impersonation of institutions or individuals

Return the forensic JSON report."""
        r = self._groq_call(prompt)
        r["pipeline"]          = "groq-only"
        r["verificationLayer"] = "VL-JEPA not applicable for text"
        r["verdictAgreement"]  = None
        return r

    # -- Stage 1: Groq prompts -----------------------------------------------

    def _image(self, image_bytes, media_type, file_name):
        size_kb = len(image_bytes) / 1024
        dims = color_mode = "unknown"
        exif_info = "No EXIF data"
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes))
            dims = f"{img.width}x{img.height}px"
            color_mode = img.mode
            try:
                exif = img._getexif()
                exif_info = (f"{len(exif)} EXIF tags present (camera chain intact)"
                             if exif else
                             "No EXIF -- common in screenshots/social-media; also typical of AI-generated images")
            except Exception:
                exif_info = "EXIF unreadable -- may have been stripped"
        except Exception:
            pass

        prompt = f"""Forensic deepfake image analysis -- Stage 1 (Groq base detection).
VL-JEPA visual encoder will independently verify your verdict in Stage 2.

FILE METADATA
  Filename   : {file_name}
  MIME       : {media_type}
  Size       : {size_kb:.1f} KB
  Dimensions : {dims}
  Color mode : {color_mode}
  EXIF       : {exif_info}

FORENSIC DIMENSIONS -- reason across ALL six:
1. EXIF CHAIN       Absence is normal for screenshots; suspicious only when other signals also converge.
2. FILE SIZE RATIO  Is {size_kb:.1f} KB typical for {dims}? AI PNGs are often suspiciously small or round-sized.
3. COLOR MODE       Is {color_mode} expected for this declared image type?
4. FILENAME PATTERN Does "{file_name}" contain AI-tool signatures: uuid, gen_, sd_, dall-e, iterative numbering?
5. RESOLUTION CUES  Powers-of-two (512x512, 1024x1024, 2048x2048) are hallmarks of diffusion models.
6. COMPRESSION      AI images often lack progressive JPEG encoding; GAN images show checkerboard DCT artifacts.

Default to SAFE unless multiple signals converge. Return the JSON report."""

        groq_r  = self._groq_call(prompt)
        vjepa_r = self._vjepa_image(image_bytes)
        return fuse(groq_r, vjepa_r)

    def _video(self, video_bytes, file_name, file_type):
        size_mb = len(video_bytes) / (1024 * 1024)

        prompt = f"""Forensic deepfake video analysis -- Stage 1 (Groq base detection).
VL-JEPA spatiotemporal encoder will independently verify in Stage 2.

FILE DETAILS
  Filename : {file_name}
  MIME     : {file_type}
  Size     : {size_mb:.2f} MB

VIDEO FORENSICS -- analyze all six dimensions:
1. FACE-SWAP         Temporal flickering, unnatural skin/hair boundaries between frames.
2. LIP-SYNC          Audio-visual synchronisation artifacts; common in face-swap pipelines.
3. FRAME CONSISTENCY Abrupt texture/resolution changes across temporal segments.
4. CODEC FINGERPRINT Unusual codecs or encoding params preferred by deepfake tools.
5. METADATA CHAIN    Missing encoder strings, suspicious or absent creation timestamps.
6. FILENAME PATTERN  Does "{file_name}" match deepfake tool naming: swap, deepfake, generated, UUID strings?

Return technically specific forensic signals. Return the JSON report."""

        groq_r  = self._groq_call(prompt)
        vjepa_r = self._vjepa_video(video_bytes)
        return fuse(groq_r, vjepa_r)

    def _audio(self, file_name, file_type):
        prompt = f"""Forensic deepfake audio analysis -- Stage 1 (Groq base detection).
Note: VL-JEPA is a visual encoder and does not apply to audio. This is the complete analysis.

FILE DETAILS
  Filename : {file_name}
  MIME     : {file_type}

AUDIO FORENSICS -- analyze all six dimensions:
1. VOICE CLONING      Unnatural prosody, robotic pitch transitions, neural TTS hallmarks.
2. SPECTRAL ANOMALIES Frequency gaps typical of TTS models; silence-floor irregularities.
3. BACKGROUND NOISE   Unnaturally clean silence between words; abrupt noise-floor changes.
4. PHASE ARTIFACTS    Click/pop at segment joins, phase discontinuities from splicing.
5. CODEC FINGERPRINT  Bitrates/formats preferred by voice-cloning pipelines (ElevenLabs, XTTS, etc.).
6. FILENAME PATTERN   Does "{file_name}" suggest a known voice-clone tool or pipeline output?

Return the JSON forensic report."""

        r = self._groq_call(prompt)
        r["pipeline"]          = "groq-only"
        r["verificationLayer"] = "VL-JEPA not applicable for audio"
        r["verdictAgreement"]  = None
        return r

    def _generic(self, file_name, file_type):
        prompt = (f"Forensic analysis of: {file_name} ({file_type}). "
                  "Analyze for deepfake or malicious content indicators. "
                  "Return the JSON forensic report.")
        r = self._groq_call(prompt)
        r["pipeline"]          = "groq-only"
        r["verificationLayer"] = "VL-JEPA not applicable"
        r["verdictAgreement"]  = None
        return r

    # -- VL-JEPA wrappers ----------------------------------------------------

    def _vjepa_image(self, image_bytes):
        try:
            return self.vjepa.predict_image(image_bytes)
        except Exception as exc:
            print(f"[VL-JEPA image] {exc}")
            return None

    def _vjepa_video(self, video_bytes):
        try:
            return self.vjepa.predict(video_bytes)
        except Exception as exc:
            print(f"[VL-JEPA video] {exc}")
            return None

    # -- Groq caller ---------------------------------------------------------

    def _groq_call(self, prompt):
        resp = self.groq.chat.completions.create(
            model=self.MODEL,
            messages=[
                {"role": "system", "content": _SYSTEM},
                {"role": "user",   "content": prompt},
            ],
            temperature=0.3,
            max_tokens=1400,
        )
        return self._parse(resp.choices[0].message.content or "")

    def _parse(self, raw):
        clean = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
        try:
            return json.loads(clean)
        except json.JSONDecodeError:
            pass
        m = re.search(r"\{.*\}", clean, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
        return {
            "verdict": "SAFE", "confidence": 30, "riskScore": 20,
            "threatType": "Analysis Error",
            "signals": [{"label": "Parse Error",
                          "value": "Could not parse AI response -- defaulting safe.",
                          "severity": "low"}],
            "summary": "Analysis engine returned an unexpected format. Defaulting to safe.",
            "recommendation": "Retry the scan. Verify your Groq API key at console.groq.com.",
            "reportToPortal": False,
        }
