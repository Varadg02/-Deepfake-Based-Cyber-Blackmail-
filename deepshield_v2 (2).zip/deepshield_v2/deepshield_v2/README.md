# DeepShield v2 — Groq LLM + VL-JEPA Deepfake Detection

Dual-engine agentic AI platform for deepfake detection and cyber blackmail threat analysis.

---

## Architecture

```
STAGE 1  Groq LLM (llama-3.3-70b-versatile)     ← BASE DETECTION
         Forensic metadata, EXIF, filename, codec analysis

         ↓

STAGE 2  VL-JEPA ViT-Huge (frozen) + AttentiveProbe  ← VERIFICATION
         Spatio-temporal visual feature extraction
         Binary real/fake classification probe
         (simulation mode when weights are absent)

         ↓

STAGE 3  Fusion Engine                           ← RECONCILIATION
         riskScore = 0.55 × groq + 0.45 × vjepa
         VL-JEPA can escalate or de-escalate Groq verdict
```

---

## Files

```
deepshield/
├── app.py              ← Streamlit UI (pipeline visualisation)
├── agent.py            ← Two-stage agent + fusion engine
├── vjepa_detector.py   ← VL-JEPA frozen encoder + AttentiveProbe
├── report.py           ← PDF evidence report generator
├── requirements.txt    ← Dependencies
└── README.md
```

---

## Quick Start

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open http://localhost:8501 — paste your free Groq key when prompted.

---

## VL-JEPA Weights (optional)

Without weights the detector runs in **simulation mode** — fully functional for demos.

To enable real VL-JEPA inference:

```bash
# 1. Download ViT-Huge checkpoint
#    https://github.com/facebookresearch/jepa (vith14.pth)

# 2. Train the probe (one-time, ~10 epochs on FaceForensics++)
python -c "
from vjepa_detector import VJEPADeepfakeDetector
det = VJEPADeepfakeDetector(encoder_weights='vith14.pth')
det.train_probe(your_train_loader, epochs=10)
# saves: deepshield_probe.pth
"

# 3. Pass weights into the agent
from agent import DeepShieldAgent
agent = DeepShieldAgent(
    api_key='gsk_...',
    vjepa_encoder_weights='vith14.pth',
    vjepa_probe_weights='deepshield_probe.pth',
)
```

---

## Free Groq API Key

1. https://console.groq.com → Login → API Keys → Create Key
2. Copy `gsk_...` and paste in the app

---

## Deploy Free (Streamlit Cloud)

1. Push to GitHub
2. share.streamlit.io → New app → select `app.py`
3. Secrets: `GROQ_API_KEY = "gsk_..."`
4. Deploy → live in ~2 min ✅
